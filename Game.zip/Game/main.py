# Main file to run game

from __future__ import division

try:
    import simplegui
except ImportError:
    import SimpleGUICS2Pygame.simpleguics2pygame as simplegui

import pygame as pg
import random
import os
from settings import *
from sprites import *
from levels import *
from os import path

os.environ['SDL_VIDEO_CENTERED'] = '1'

class Game:
    def __init__(self):
        # INITIALIZE GAME SETTINGS
        pg.init()
        pg.mixer.init()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        self.running = True
        self.font_name = pg.font.match_font(FONT_NAME)
        self.load_data()
        self.back_to_home = False
        self.home_screen = False
        self.game_over_screen = False
        self.score = 0
        self.lives = 3

    def load_data(self):

        # DEFINE FILE DIRECTORY
        self.dir = path.dirname(__file__)

        # LOAD FOLDERS
        img_dir = path.join(self.dir, "img")
        font_dir = path.join(self.dir, "fonts")
        sound_dir = path.join(self.dir, "sound")

        # LOAD PLAYER/ENEMY SPRITESHEET
        self.characters = Spritesheet(path.join(img_dir, CHARACTER))

        # LOAD BUTTONS
        self.buttons = Spritesheet(path.join(img_dir, BUTTON_IMAGES))
        self.yellowButton1 = self.buttons.get_image(YELLOW_BUTTON1, 1)
        self.yellowButton1.set_colorkey(BLACK)

        # LOAD FONT
        self.title_font = path.join(font_dir, "font1.ttf")

        # LOAD SOUNDS
        #self.an_example_sound = pg.mixer.Sound(path.join(self.sound_dir, "sound_example.wav"))

    def new(self):
        # START A NEW GAME
        self.paused = False
        self.back_to_home = False
        self.game_over_screen = False

        # ADD SPRITE GROUPS
        self.all_sprites = pg.sprite.LayeredUpdates()
        self.platforms = pg.sprite.Group()
        self.enemies = pg.sprite.Group()

        # CREATE PLAYER AND ADD THEM TO SPRITES
        self.player = Player(self)
        self.all_sprites.add(self.player)

        # KEEP TRACK OF ENEMY TIMER AND COUNT
        self.enemies_timer = 0
        self.enemies_count = 0

        self.current_level = Level_1(g, self.player, self.all_sprites)

        # RUN THE GAME LOOP
        self.run()

    def run(self):
        # RUN GAME LOOP
        self.playing = True

        # WHILE THE GAME IS STILL PLAYING
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            if not self.paused:
                self.update()
            self.draw()

    def update(self):
        # UPDATE GAME LOOP
        #self.all_sprites.update()
        self.current_level.update()
        #

        # Spawn new enemy
        now = pg.time.get_ticks()

        if now - self.enemies_timer > 10000 and self.enemies_count <= 3:
            self.enemies_timer = now
            self.new_enemy = Enemy(self)
            self.enemies_count += 1
            self.enemies.add(self.new_enemy)
            print("NEW ENEMY NO. " + str(self.enemies_count))

        if self.enemies_count >= 1 and self.enemies_count <= 3:
            self.new_enemy.update()

            # Check if enemy hits a platform, only if falling
            if self.new_enemy.vel.y > 0:
                hits = pg.sprite.spritecollide(self.new_enemy, self.platforms, False)
                if hits:
                    self.new_enemy.pos.y = hits[0].rect.top
                    self.new_enemy.vel.y = 0
                    self.new_enemy.jumping = False

            self.new_enemy.acc.x = ENEMY_ACC



        hits_platform = pg.sprite.spritecollide(self.player, self.platforms, False)
        hits_enemy = pg.sprite.spritecollide(self.player, self.enemies, False)
        # Check if player hits a platform, only if falling
        if self.player.vel.y >= 0:
            if hits_platform:
                self.player.pos.y = hits_platform[0].rect.top
                self.player.vel.y = 0
                self.player.jumping = False
            if hits_enemy:
                for enemy in hits_enemy:
                    if self.player.rect.bottom <= enemy.rect.centery:
                        print("PLAYER HIT ENEMY ON TOP")
                        enemy.kill()
                        #self.score += 1000
                        if self.enemies_count > 0:
                            self.enemies_count -= 1

        if hits_enemy:
            for enemy in hits_enemy:
                if self.player.rect.centerx >= hits_enemy[0].rect.right:
                    enemy.kill()
                    self.player.kill()
                    self.lives -= 1
                    self.playing = False
                    print("ENEMY KILLED PLAYER")


         # If enemy falls and dies
        for enemy in self.enemies:
            if enemy.rect.bottom > HEIGHT or enemy.rect.left > WIDTH:
                enemy.kill()
                if self.enemies_count > 0:
                    self.enemies_count -= 1

        # Check if player hits the side of a platform
        # See if we hit anything

        hits = pg.sprite.spritecollide(self.player, self.platforms, False)

        for hit in hits:
            # If we are moving right,
            # set our right side to the left side of the item we hit
            if hit.rect.bottom == HEIGHT - 64:
                if self.player.vel.x >= 0:
                    self.player.rect.right = hit.rect.left
                elif self.player.vel.x <= 0:
                    # Otherwise if we are moving left, do the opposite.
                    self.player.rect.left = hit.rect.right

        # If player falls and dies
        if self.player.rect.bottom > HEIGHT:
            for sprite in self.all_sprites:
                sprite.rect.y -= max(self.player.vel.y, 10)
                if sprite.rect.bottom < 0:
                    sprite.kill()
        if len(self.platforms) == 0:
            self.lives -= 1
            self.playing = False

        # If the player gets near the right side, shift the world left (-x)
        if self.player.pos.x > 500 and abs(self.player.vel.x) > 0:
            shift = self.player.pos.x - 500
            self.player.pos.x = 500
            self.current_level.shift_world(-shift)


        # If the player gets near the left side, shift the world right (+x)
        if self.player.pos.x <= 300 and self.player.vel.x < 0:
            shift = 300 - self.player.pos.x
            self.player.pos.x = 300
            self.current_level.shift_world(shift)


        # If the player gets to the end of the level, go to the next level
        current_position = self.player.rect.x + self.current_level.world_shift
        # print("Current position: " + str(current_position))
        if current_position < self.current_level.level_limit:
            self.player.rect.x = 120
            for platform in self.platforms:
                platform.kill()
            self.current_level = Level_2(g, self.player, self.all_sprites)

    def events(self):
        # EVENTS TO HANDLE DURING GAME

        for event in pg.event.get():

            pos = pg.mouse.get_pos()
            x = pos[0]
            y = pos[1]

            # PAUSE SCREEN OPTIONS
            continue_button = (x >= 300 and x <= 490) and (y >= 220 and y <= 270)
            restart_button = (x >= 300 and x <= 490) and (y >= 280 and y <= 330)
            home_button = (x >= 300 and x <= 490) and (y >= 340 and y <= 390)
            exit_button = (x >= 300 and x <= 490) and (y >= 400 and y <= 450)

            # CHECK FOR CLOSING WINDOW
            if event.type == pg.QUIT:
                if self.playing:
                    self.lives = 0
                    self.playing = False
                self.running = False

            # CHECK IF USER PRESSES SPACE TO JUMP
            if event.type == pg.KEYUP:
                if event.key == pg.K_UP:
                    self.player.jump_cut()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_UP:
                    self.player.jump()

                # CHECK IF GAME IS BEING PAUSED
                if event.key == pg.K_p:
                    self.paused = not self.paused
                    if self.paused:
                        self.dim_screen = pg.Surface(self.screen.get_size()).convert_alpha()
                        self.dim_screen.fill((0, 0, 0, 180))

                # CHECK IF USER PRESSED 'ESC' TO QUIT
                if event.key == pg.K_ESCAPE:
                    if self.playing:
                        self.lives = 0
                        self.playing = False
                    self.running = False

            # PAUSE SCREEN EVENTS
            if event.type == pg.MOUSEBUTTONDOWN and self.paused:

                if continue_button:
                    self.paused = False

                if restart_button:
                    self.lives = 3
                    self.score = 0
                    self.playing = False

                if home_button:
                    self.lives = 0
                    self.score = 0
                    self.playing = False
                    self.back_to_home = True

                if exit_button:
                    self.lives = 0
                    self.playing = False
                    self.running = False

    def draw(self):
       # DRAW GAME LOOP

        # DRAW CURRENT LEVEL
        self.current_level.draw(self.screen)

        # SCORE AND LIVES TEXT AT TOP OF SCREEN
        self.draw_text("Score: " + str(self.score), 22, BLACK, (WIDTH / 4), 15)
        self.draw_text("Lives: " + str(self.lives), 22, BLACK, (WIDTH * (3 / 4)), 15)

        # PAUSE SCREEN
        if self.paused:
            self.screen.blit(self.dim_screen, (0, 0))
            self.draw_text("Paused", 40, WHITE, WIDTH / 2, HEIGHT / 4)
            self.draw_button("Continue", 300, (HEIGHT * (4 / 5)) - 180)
            self.draw_button("Restart", 300, (HEIGHT * (4 / 5)) - 120)
            self.draw_button("Home", 300, (HEIGHT * (4 / 5)) - 60)
            self.draw_button("Exit", 300, ((HEIGHT * (4 / 5))))

        # *after* drawing everything, flip the display - nothing else should go below this line
        pg.display.flip()

    def wait_for_user(self):
        # WAIT FOR USER TO MAKE CHOICE IN MENU

        waiting = True
        while waiting:
            self.clock.tick(FPS)

            pos = pg.mouse.get_pos()
            x = pos[0]
            y = pos[1]

            # GAME OVER SCREEN
            play_again_button = (x >= 300 and x <= 488) and (y >= 280 and y <= 330)
            home_button = (x >= 300 and x <= 488) and (y >= 340 and y <= 390)

            # WELCOME SCREEN
            play_button = (x >= 300 and x <= 488) and (y >= 340 and y <= 390)

            # BOTH SCREENS
            exit_button = (x >= 300 and x <= 488) and (y >= 400 and y <= 450)

            for event in pg.event.get():

                # EXITING
                if event.type == pg.QUIT:
                    self.lives = 0
                    waiting = False
                    self.running = False

                if event.type == pg.KEYUP:
                    if event.key == pg.K_ESCAPE:
                        self.lives = 0
                        waiting = False
                        self.running = False

                    # PLAY / PLAY AGAIN
                    if event.key == pg.K_RETURN:
                        if self.home_screen:
                            waiting = False
                        if self.game_over_screen:
                            self.lives = 3
                            self.score = 0
                            self.game_over_screen = False
                            waiting = False
                            self.playing = True

                # HOME SCREEN
                if event.type == pg.MOUSEBUTTONDOWN and self.home_screen:

                    if play_button:
                        waiting = False

                    if exit_button:
                        self.lives = 0
                        waiting = False
                        self.running = False

                # GAME OVER SCREEN
                if event.type == pg.MOUSEBUTTONDOWN and self.game_over_screen:

                    if play_again_button:
                        self.lives = 3
                        self.score = 0
                        self.game_over_screen = False
                        waiting = False
                        self.playing = True

                    if home_button:
                        self.game_over_screen = False
                        waiting = False
                        self.back_to_home = True

                    if exit_button:
                        self.lives = 0
                        self.game_over_screen = False
                        waiting = False
                        self.running = False

    def show_start_screen(self):
        # WELCOME SCREEN

        self.home_screen = True
        self.score = 0
        self.lives = 3

        self.screen.fill(BG_COLOUR)
        self.draw_text(TITLE, 30, BLACK, 400, 100)
        self.draw_text("Use the Left/Right arrow keys to move left and right. Up arrow to jump", 20, BLACK, 400, 200)
        self.draw_text("Avoid the baddies. Jump on top of them to kill them", 20, BLACK, 400, 260)
        self.draw_button("Play", 300, 340)
        self.draw_button("Exit", 300, 400)

        # *after* drawing everything, flip the display - no other drawings/text should go below this line
        pg.display.flip()

        self.wait_for_user()
        self.home_screen = False

    def show_go_screen(self):
        # GAME OVER SCREEN

        if not self.running:
            return

        self.game_over_screen = True

        self.screen.fill(BG_COLOUR)
        self.draw_text("GAME OVER", 50, WHITE, WIDTH / 2, (HEIGHT / 4) - 40)
        self.draw_text("Score: " + str(self.score), 22, WHITE, WIDTH / 2, (HEIGHT / 3) + 50)

        self.draw_button("Play Again", 300, 280)
        self.draw_button("Home", 300, 340)
        self.draw_button("Exit", 300, 400)

        pg.display.flip()

        self.wait_for_user()

    def draw_text(self, text, size, colour, x, y):
        # METHOD TO WRITE TEXT ON SCREEN
        font = pg.font.Font(self.title_font, size)
        text_surface = font.render(text, True, colour)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        self.screen.blit(text_surface, text_rect)

    def draw_button(self, text, x, y):
        # METHOD TO DRAW BUTTON ON SCREEN
        self.screen.blit(self.yellowButton1, (x, y))
        self.draw_text(text, 22, BLACK, x + 90, y + 10)


# START OF PROGRAM AND INITIALIZING GAME #
g = Game()

# SHOW START SCREEN AFTER INITIALIZING GAME
g.show_start_screen()


# WHILE THE PROGRAM CONTINUES TO RUN
while g.running:
    while g.lives > 0:
        # EACH TIME THE PLAYER DIES, START A NEW GAME, UNTIL THEY HAVE NO LIVES LEFT
        g.new()
    if not g.back_to_home:
        g.show_go_screen()
    else:
        g.show_start_screen()

# AS SOON AS RUNNING BECOMES FALSE, PROGRAM WILL END
pg.quit()
